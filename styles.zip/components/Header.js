import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Header.css';

const Header = () => {
    return (
        <header>
            <div className="logo">
                <img src="logo.png" alt="Restaurant Logo" />
            </div>
            <nav>
                <ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/menu">Menu</Link></li>
                    <li><Link to="/gallery">Gallery</Link></li>
                    <li><Link to="/payment">Payment</Link></li>
                    <li><Link to="/careers">Careers</Link></li>
                    <li><Link to="/events">Events</Link></li>
                    <li><Link to="/signup">Signup</Link></li>
                </ul>
            </nav>
            <div className="nav-buttons">
                <button className="nav-button"><i>❓</i> Help</button>
                <button className="nav-button"><i>👤</i> SignIn or Login</button>
            </div>
        </header>
    );
};

export default Header;
