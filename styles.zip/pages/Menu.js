import React from 'react';
import '../styles/menu.css';

const Menu = () => {
  return (
    <div>
      <h1 style={{ textAlign: 'center', fontFamily: 'Arial, sans-serif' }}>Menu</h1>
      <h2 style={{ textAlign: 'center', fontFamily: 'Arial, sans-serif' }}>★ Good Kitchen ★</h2>

      {/* Starters Section */}
      <h3 style={{ fontFamily: 'Arial, sans-serif', fontSize: '22px' }}>Starters</h3>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Gobi Manchurian</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹150</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Paneer Chilly</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹190</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Baby Corn Pepper Dry</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹180</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Spring Rolls</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹200</span>
        </div>
      </div>
      <img
        src="/assets/images/gobi.jpeg"
        alt="Gobi Manchurian"
        height="140"
        width="180"
        style={{ margin: '10px', display: 'block', marginLeft: 'auto', marginRight: 'auto' }}
      />

      {/* Curry Section */}
      <h3 style={{ fontFamily: 'Arial, sans-serif', fontSize: '22px' }}>Curries</h3>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Butter Chicken</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹280</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Chicken Curry</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹270</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Paneer Butter Masala</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹240</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Dal Tadka</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹180</span>
        </div>
      </div>
      <img
        src="/assets/images/chicken.jpeg"
        alt="Chicken Curry"
        height="140"
        width="180"
        style={{ margin: '10px', display: 'block', marginLeft: 'auto', marginRight: 'auto' }}
      />

      {/* Rice Section */}
      <h3 style={{ fontFamily: 'Arial, sans-serif', fontSize: '22px' }}>Rice</h3>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Veg Biryani</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹250</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Chicken Biryani</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹300</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Veg Fried Rice</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹220</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Chicken Fried Rice</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹240</span>
        </div>
      </div>
      <img
        src="/assets/images/rice.jpeg"
        alt="Veg Biryani"
        height="140"
        width="180"
        style={{ margin: '10px', display: 'block', marginLeft: 'auto', marginRight: 'auto' }}
      />

      {/* Noodles Section */}
      <h3 style={{ fontFamily: 'Arial, sans-serif', fontSize: '22px' }}>Noodles</h3>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Veg Noodles</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹180</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Chicken Noodles</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹220</span>
        </div>
      </div>
      <img
        src="/assets/images/Noodles.jpeg"
        alt="Noodles"
        height="140"
        width="180"
        style={{ margin: '10px', display: 'block', marginLeft: 'auto', marginRight: 'auto' }}
      />

      {/* Desserts Section */}
      <h3 style={{ fontFamily: 'Arial, sans-serif', fontSize: '22px' }}>Desserts</h3>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Ice Cream</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹120</span>
        </div>
        <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>Gulab Jamun</span>
          <span style={{ fontFamily: 'Arial, sans-serif' }}>₹100</span>
        </div>
      </div>
      <img
        src="/assets/images/Ice.jpeg"
        alt="Ice Cream"
        height="140"
        width="180"
        style={{ margin: '10px', display: 'block', marginLeft: 'auto', marginRight: 'auto' }}
      />
    </div>
  );
};

export default Menu;
