import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import '../styles/Gallery.css';

const Gallery = () => {
  return (
    <div>
      <Header />
      
      <div className="gallery-container">
        <br /><br />
        <div className="gallery-title">Gallery</div>
        <div className="image-grid">
          <img src="/assets/images/t2.jpeg" alt="Image 1" />
          <img src="/assets/images/c1.jpeg" alt="Image 2" />
          <img src="/assets/images/c2.jpeg" alt="Image 3" />
          <img src="/assets/images/t1.jpeg" alt="Image 4" />
        </div>
        <div className="image-grid">
          <img src="/assets/images/s2.jpeg" alt="Image 5" />
          <img src="/assets/images/s1.jpeg" alt="Image 6" />
          <img src="/assets/images/t1.jpeg" alt="Image 7" />
          <img src="/assets/images/c2.jpeg" alt="Image 8" />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Gallery;
