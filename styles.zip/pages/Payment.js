import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import '../styles/Payment.css';

const Payment = () => {
  return (
    <div>
      <Header />
      <div className="container">
        {/* Event Information Section */}
        <div className="event-info">
          <h3>
            Event Name : <span>Birthday Event</span>
          </h3>
          <div className="price-summary">
            <h3>Price Summary:</h3>
            <p>
              Amount : <span>₹ 5,999</span>
            </p>
            <p>
              Extra Decoration : <span>₹ 2,000</span>
            </p>
            <p>
              Tax : 7% <span>₹ 235</span>
            </p>
            <p className="total">
              Total : <span>₹ 8,234</span>
            </p>
          </div>
        </div>

        {/* Payment Section */}
        <div className="payment-section">
          <h3>Recommended</h3>
          <div className="card-form">
            <p>Credit / Debit / ATM Card</p>
            <input type="text" placeholder="Card Number" />
            <input type="text" placeholder="Valid Thru" />
            <input type="text" placeholder="CVV" />
            <button>Pay ₹ 8,234</button>
            <select>
              <option>Net Banking</option>
            </select>
            <select>
              <option>Pay Using UPI</option>
            </select>
            <select>
              <option>Cash On Day</option>
            </select>
          </div>
        </div>

        {/* Details Section */}
        <div className="details-section">
          <h3>Details</h3>
          <img
            src="https://via.placeholder.com/200x300"
            alt="Birthday Event Decoration"
          />
          <p>
            Birthday Event, with decoration and family dinner.<br />
            The same with the additional details will be mailed to the registered email ID.
          </p>
        </div>
      </div>

      {/* Enjoy The Event Section */}
      <div className="enjoy-event">Enjoy The Event...!</div>

      <Footer />
    </div>
  );
};

export default Payment;
