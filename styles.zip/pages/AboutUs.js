import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import '../styles/AboutUs.css';

const AboutUs = () => {
    return (
        <div>
            <Header />
            <section className="hero1">
                <h1>FOOD IS SYMBOLIC OF LOVE WHEN WORDS ARE INADEQUATE</h1>
                <p>Crafted to perfection, served with elegance</p>
            </section>
            <section className="about-us">
                <div className="about-content">
                    <h2>About Us</h2>
                    <p>
                        Welcome to Golden Flavors, where culinary excellence meets unforgettable experiences! 
                        Nestled in the heart of Bangalore, our restaurant has been a beloved gathering place for 
                        food enthusiasts and families alike. Since opening our doors in 2001, we have committed 
                        ourselves to providing an atmosphere that blends warmth, elegance, and the joy of sharing a meal.
                    </p>
                    <h2>Our Story</h2>
                    <p>
                        Golden Flavors began as a vision to create a dining experience that celebrates both tradition 
                        and innovation. Founded by ABCD, a passionate chef with a love for authentic Biryani, our journey 
                        started with a simple goal: to craft dishes that tell a story. Over the years, our dedication to 
                        sourcing fresh, local ingredients and creating seasonal menus has earned us a reputation for both 
                        quality and creativity.
                    </p>
                </div>
                <div className="about-images">
                    <div className="image-container">
                        <img src="/images/image1.png" alt="Restaurant Image 2" className="image1" />
                        <img src="/images/image2.png" alt="Restaurant Image 1" className="image2" />
                    </div>
                </div>
            </section>
            <Footer />
        </div>
    );
};

export default AboutUs;
