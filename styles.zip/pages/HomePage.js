import React from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import '../styles/homepage.css';


const HomePage = () => {
  const navigate = useNavigate(); 

  const handleExploreClick = () => {
    navigate('/about-us'); 
  };

  return (
    <div className="app">
      <Header />
      <section className="hero-wrapper">
        <div className="hero-background"></div>
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <h2>Golden Flavors, Unforgettable Moments</h2>
          <h1>
            IT'S ALL ABOUT <span>GOOD</span> FOOD
          </h1>
          <p>
            Crafted to perfection, served with elegance.
            <br />
            Experience dining like never before.
          </p>
          <p>
            Enjoy <span className="highlight-percent">30%</span> Off on Your
            First Order
          </p>
          <button className="explore-button" onClick={handleExploreClick}>
            Explore Now
          </button>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default HomePage;
