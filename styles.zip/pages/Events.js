import React from 'react';
import '../styles/events.css';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Events = () => {
  const eventServices = [
    {
      imgSrc: '/birthday.jpg',
      title: 'Birthday Events',
      description: 'Celebrate your birthday with us for an unforgettable experience filled with great food and warm ambiance.',
      price: '₹5,999',
    },
    {
      imgSrc: '/surprise.jpg',
      title: 'Surprise Events',
      description: 'Turn your special moments into unforgettable memories with our unique event experiences.',
      price: '₹7,999',
    },
    {
      imgSrc: '/baby-shower.jpg',
      title: 'Baby Shower Events',
      description: 'Celebrate the joy of new beginnings with an unforgettable baby shower experience at our restaurant.',
      price: '₹10,000',
    },
    {
      imgSrc: '/anniversary.jpg',
      title: 'Anniversary Events',
      description: 'Celebrate your love story with an unforgettable anniversary event at our restaurant.',
      price: '₹6,999',
    },
    {
      imgSrc: '/to-be.jpg',
      title: 'Bride/Groom Events',
      description: "Celebrate your 'to-be' moments with us, where every detail makes your special day unforgettable.",
      price: '₹9,999',
    },
  ];

  return (
    <>
    <Header/>
    <main className="events">
      <div className="service-container">
        <h1>Events</h1>
        <div className="service-row">
          {eventServices.map((service, index) => (
            <div className="service" key={index}>
              <img src={service.imgSrc} alt={service.title} />
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <h2>{service.price}</h2>
              <button>Book</button>
            </div>
          ))}
        </div>
        <div className="note-container">
          <p>Note: Prices may differ according to your requirements.</p>
        </div>
      </div>
    </main>
    <Footer/>
    </>
  );
};

export default Events;
