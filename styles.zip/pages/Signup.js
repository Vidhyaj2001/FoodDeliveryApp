import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import '../styles/signup.css';

const Signup = () => {
  const [formType, setFormType] = useState('signup');
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const navigate = useNavigate();

  const toggleForm = (type) => {
    setFormType(type);
    setFormData({ username: '', email: '', password: '', confirmPassword: '' });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const apiEndpoint = formType === 'signup' ? '/api/signup' : '/api/login';
    const { username, email, password, confirmPassword } = formData;

    if (formType === 'signup' && password !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    try {
      const response = await fetch(apiEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(
          formType === 'signup'
            ? { username, email, password }
            : { email, password }
        ),
      });

      const data = await response.json();

      if (response.ok) {
        if (formType === 'login') {
          alert('Login successful!');
          navigate('/');
        } else {
          alert('Sign-up successful! Please login.');
          toggleForm('login');
        }
      } else {
        alert(data.message || 'Something went wrong!');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error connecting to the server.');
    }
  };

  return (
    <>
      <Header />
      <div className="hero-wrapper">
        {/* Background and Overlay */}
        <div className="hero-background"></div>
        <div className="hero-overlay"></div>

        {/* Form Content */}
        <div className="hero-content">
          <div className="form-container">
            {formType === 'signup' ? (
              <form onSubmit={handleSubmit}>
                <h2>Sign Up</h2>
                <label>Username</label>
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder="Enter your username"
                  required
                />
                <label>Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  required
                />
                <label>Password</label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Enter your password"
                  required
                />
                <label>Confirm Password</label>
                <input
                  type="password"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="Confirm your password"
                  required
                />
                <button type="submit">Sign Up</button>
                <p className="toggle-form">
                  Already have an account?{' '}
                  <button type="button" onClick={() => toggleForm('login')} className="toggle-form-btn">
                    Login
                  </button>
                </p>
              </form>
            ) : (
              <form onSubmit={handleSubmit}>
                <h2>Login</h2>
                <label>Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  required
                />
                <label>Password</label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Enter your password"
                  required
                />
                <button type="submit">Login</button>
                <p className="toggle-form">
                  Don't have an account?{' '}
                  <button type="button" onClick={() => toggleForm('signup')} className="toggle-form-btn">
                    Sign Up
                  </button>
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Signup;
