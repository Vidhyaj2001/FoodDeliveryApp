import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import '../styles/ContactUs.css';

const ContactUs = () => {
  return (
    <div>
      <Header />
      <main>
        <div className="overlay"></div>
        <section className="contact-section">
          <h1>Contact Us</h1>
          <br />
          <h2>HOW TO GET IN TOUCH?</h2>
          <br />
          <p>
            This section proves that you are approachable and ready to accept
            reviews and prior bookings. People love to be <br />
            associated with businesses that are friendly and communicate well. Encourage them to get in touch
            with you.
          </p>
          <div className="contact-container">
            <div className="contact-details">
              <p>
                <strong>Address:</strong>
                <br /> #123, abc Cross, Bangalore - 100001, Karnataka, India
              </p>
              <br />
              <p>
                <strong>Phone Number:</strong>
                <br /> +91 1234567890
              </p>
              <br />
              <p>
                <strong>Email Address:</strong>
                <br /> goldenflavours@gmail.com
              </p>
              <br />
              <div className="social-links">
                <a href="#">
                  <img src="insta.png" alt="Instagram" />
                </a>
                <a href="#">
                  <img src="facebook.png" alt="Facebook" />
                </a>
                <a href="#">
                  <img src="twitter.png" alt="Twitter" />
                </a>
                <a href="#">
                  <img src="whatsapp.png" alt="WhatsApp" />
                </a>
              </div>
            </div>
            <div className="contact-form">
              <form>
                <div className="form-row" style={{ width: "105%" }}>
                  <input type="text" placeholder="Your Name" className="form-input" />
                  <input type="email" placeholder="Your Email" className="form-input" />
                </div>
                <input type="text" placeholder="Subject" className="form-input" />
                <textarea placeholder="Message" className="form-textarea"></textarea>
                <button type="submit" className="form-button">
                  Submit
                </button>
              </form>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default ContactUs;
