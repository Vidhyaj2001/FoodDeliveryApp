import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Service = ({ image, description, name }) => {
    return (
        <div className="service">
            <img src={image} alt={name} />
            <p>{description}</p>
        </div>
    );
};

const CareerSection = () => {
    return (
        <div className="service-container" style={{ borderRadius: "0px", marginTop: "0px", marginBottom: "0px" }}>
            <h1>Careers</h1>
            <div className="service-row">
                <Service
                    image="chef1.jpg"
                    description={"When we talk about chefs on TV, the first person to come to mind is Sanjeev Kapoor, a celebrity chef known for 'Khana Khazana'."}
                    name="Chef Sanjeev Kapoor"
                />
                <Service
                    image="chef2.jpg"
                    description={"Kunal Kapur, a well-known celebrity chef, previously a MasterChef India judge, has won multiple awards."}
                    name="Chef Kunal Kapur"
                />
                <Service
                    image="chef3.jpg"
                    description={"Sihi Kahi Chandru presents the cooking show 'Bombat Bhojana' on Kannada TV channel Suvarna."}
                    name="Chef Sihi Kahi Chandru"
                />
                <Service
                    image="chef4.jpg"
                    description={"Pankaj Bhadouria, winner of MasterChef India Season 1, transitioned from teaching to a culinary star."}
                    name="Chef Pankaj Bhadouria"
                />
            </div>

            <div>
                <h1 style={{ paddingLeft: "80px", paddingRight: "80px", marginLeft: "42%" }}>Hiring</h1>
            </div>

            <div className="service-container" style={{ backgroundColor: "gray", color: "white" }}>
                <p style={{ fontSize: "26px" }}>
                    <span style={{ color: "black" }}><b>Join Our Team</b></span> - Exciting Opportunities in the Culinary and Hospitality Industry!<br />
                    Are you passionate about creating unforgettable dining experiences? We're looking for enthusiastic individuals to join our dynamic team.
                </p>
                <h2 style={{ textAlign: "left", fontSize: "26px", marginTop: "20px", paddingLeft: "17px" }}><b style={{ color: "black" }}>Why Join Us?</b></h2>
                <ul style={{ fontSize: "26px", textAlign: "left", listStyleType: "disc", paddingLeft: "60px", marginTop: "10px" }}>
                    <li><b style={{ color: "black" }}>Career Growth:</b> Opportunities for advancement.</li>
                    <li><b style={{ color: "black" }}>Creative Environment:</b> Work with skilled professionals.</li>
                    <li><b style={{ color: "black" }}>Training & Development:</b> Comprehensive training programs.</li>
                    <li><b style={{ color: "black" }}>Competitive Benefits:</b> Supportive culture, competitive pay, and perks.</li>
                </ul>
            </div>

            <div style={{ textAlign: "left", fontSize: "32px", marginTop: "20px", paddingLeft: "10px" }}>
                <b>Positions Available:</b>
            </div>

            <div className="service-container" style={{ padding: "20px", backgroundColor: "#FFD700" }}>
                <p style={{ fontSize: "29px", margin: "0" }}>
                    <span style={{ fontSize: "32px" }}><b>Chefs:</b></span> Showcase your culinary skills. <a href="#">Apply</a>
                </p>
            </div>

            <div className="service-container" style={{ padding: "20px", backgroundColor: "#FFD700" }}>
                <p style={{ fontSize: "29px", margin: "0" }}>
                    <span style={{ fontSize: "32px" }}><b>Hotel Staff:</b></span> Join a welcoming team. <a href="#">Apply</a>
                </p>
            </div>

            <div className="service-container" style={{ padding: "20px", backgroundColor: "#FFD700" }}>
                <p style={{ fontSize: "29px", margin: "0" }}>
                    <span style={{ fontSize: "32px" }}><b>Waiters:</b></span> Bring smiles with attentive service. <a href="#">Apply</a>
                </p>
            </div>
        </div>
    );
};

const Careers = () => {
    return (
        <>
            <Header />
            <CareerSection />
            <Footer />
        </>
    );
};

export default Careers;
